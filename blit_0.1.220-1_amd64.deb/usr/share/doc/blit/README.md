# blit desktop bundle

This bundle contains the TCC-built Blit server and SDL3 library. It does not
contain Hibr. Hibr must already be installed and its desktop session script
and modules must be available on the target machine.

This is an x86-64 glibc/direct-KMS bundle. Run it from a real Linux VT, not
from inside X11 or Wayland. It uses Blit's production PTY/ANSI bridge and
direct DRM page flips; SDL remains available for optional canvas/effects.

## Start Blit

```sh
BLIT_DISPLAY_BACKEND=kms BLIT_BIND_ADDRESS=127.0.0.1 blit 8080
```

Defaults are loopback TCP port `8080` and a full-width `1x1` primary pane. Override

```sh
BLIT_PANE_LAYOUT=2x2 BLIT_DISPLAY_BACKEND=kms blit 8080
```

The KMSDRM backend needs permission to access `/dev/dri`. If you only want to
exercise the API without a physical display, use `SDL_VIDEODRIVER=dummy`.

The bundle selects its packaged Unicode Terminus PSF font automatically and
logs the selected font, dimensions, and glyph count in the server log. The
render gate defaults to 16 ms for responsive pointer updates; tune it for a
slow machine with `BLIT_RENDER_INTERVAL_MS=33` or another value from 1 to
100 ms.

## Start the primary and joined display through the API

In another terminal, discover the pane IDs:

```sh
curl --fail http://127.0.0.1:8080/v1/topology
```

Create the primary and auxiliary Hibr terminal sessions with POST requests.
The command and its `desktop --join` arguments are Hibr's responsibility; Blit
only supplies the PTY-backed surface and pane placement. Replace the pane IDs
with the values returned by topology:

```sh
curl --fail --request POST http://127.0.0.1:8080/v1/terminal-sessions \
  --header 'Content-Type: application/json' \
  --data '{"command":"/usr/bin/hibr","arguments":["desktop"],"pane_id":"pane-display-1-1","surface":{"width":120,"height":40}}'
curl --fail --request POST http://127.0.0.1:8080/v1/terminal-sessions \
  --header 'Content-Type: application/json' \
  --data '{"command":"/usr/bin/hibr","arguments":["desktop","--join"],"pane_id":"pane-display-1-2","surface":{"width":120,"height":40}}'
```

The auxiliary uses Hibr's real `--join` behavior and joins the primary held
desktop session. Verify the shared session with Hibr's `hold` command:

```sh
TMPDIR=${BLIT_HIBR_TMPDIR:-/tmp/hibr-hold-blit} \
HIBR_MODPATH=/usr/lib/hibr \
/usr/bin/hibr -c 'need hold; hold clients blit'
```

## Bundle contents

- `/usr/bin/blit` — direct Blit API/display server entry point
- `lib/libSDL3.so*` — SDL3 library used by the server
- `openapi/blit-0.1.yaml` — normative API schema
- `docs/` — integration and gateway test notes
